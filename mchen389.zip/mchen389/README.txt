Install sklearn, numpy, pandas into a conda environment with Python 3.6
(actually most Python 3 environments should work...)


Run `python digits_and_faces.py` to analyze MNIST digit data
Run `python concrete_data.py` to analyze concrete data


Please don't hesitate to call 434-242-6784 if you have trouble running. I will help at all costs.
